<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Interior Website</title>
	<link href="default.css" rel="stylesheet" type="text/css" />
</head>

	<body>
		<div class="wrapper">
            <header>
            	<a href="index.html"><div class="logo">
                	
                </div></a>
                <div class="taskbar">
                    		<div class="account_taskbar"> <br /><a href="sign-in.html">Tài khoản</a></div>
                            
                        	<div class="text_taskbar">Bạn có <span class="text_red"> 0 sản phẩm</span> <br />trong giỏ hàng</div>
							
                            <div class="btn_taskbar"><a href="https://www.youtube.com/watch?v=NU3nhzS6e14"><img src="images/i_cart.png" width="31" height="29" /></a></div>
                        
                </div>
            </header>
            
          <nav class="nav-4">
            	<ul>
                	<li><a href="index.html">Trang chủ</a></li>
                   	<li><a href="newproducts.html">Sản phẩm mới</a></li>
                   	<li><a href="specialproducts.html">Sản phẩm đặc biệt</a></li>
                   	<li><a href="allproducts.html">Tất cả sản phẩm</a></li>
                   	<li><a href="faqs.html">Câu hỏi thường gặp</a></li>
                   	<li><a href="contact.html">Liên hệ</a></li>
                </ul>
                <div class="search">
                	<input type="search" class="text_search" placeholder="Tìm kiếm"/>
                    <input type="submit" class="btn_search" value="GO"/>
                </div>   
            </nav>
            
          <aside>
            	<div class="aside_1">
               		<ul>
                    	<li>Đồ theo phòng</li>
                        <li><a href="#">Phòng tắm</a></li>
                        <li><a href="#">Phòng ngủ</a></li>
                        <li><a href="#">Phòng ăn</a></li>
                        <li><a href="#">Lối vào</a></li>
                        <li><a href="#">Phòng trò chơi</a></li>
                        <li><a href="#">Nhà bếp</a></li>
                        <li><a href="#">Phòng khách</a></li>
                        <li><a href="#">Misc</a></li>
                        <li><a href="#">Văn phòng</a></li>
                        <li><a href="#">Ngoại thất</a></li>
                        <li><a href="#">Đồ trang trí mỹ nghệ</a></li>
                        <li><a href="#"><span class="text_red">Xem thêm...<span></a></li>
                    </ul>  
              	</div>
          		
	            <div class="aside_1">
                <ul>
                    	<li>Đồ theo danh mục</li>
                        <li><a href="#">Nội thất gỗ</a></li>
                        <li><a href="#">Nội thất thủy tinh</a></li>
                        <li><a href="#">Nội thất đồng</a></li>
                        <li><a href="#">Nội thất da</a></li>
                        <li><a href="#">Nội thất thạch cao</a></li>
                        <li><a href="#">Nội thất nhựa</a></li>
                        <li><a href="#">Nội thất đã qua sử dụng</a></li>
                        <li><a href="#"><span class="text_red">Xem thêm...<span></a></li>
                  </ul>
                </div>
                
                <div class="aside_3"><img src="images/img_specialoffer.png" width="188" height="152" /></div>
          </aside>
          
          
            
            <article>
    		   <div class="products_intro">
                		<img src="images/hr_fp.png" width="741" height="2" />
            			<div class="products_title">TẤT CẢ SẢN PHẨM</div>
                		<img src="images/hr_fp.png" width="741" height="2" />
              </div>
            	
              <div class="special_products">
                    <?php
                        function GioiHanKiTu($str,$limit=100){
                            if(strlen($str)<=$limit) return $str;
                            return mb_substr($str,0,$limit-3,'UTF-8').'...';
                        }

						$link = mysqli_connect("localhost", "root", "");
						mysqli_set_charset($link, 'UTF8');
						mysqli_select_db($link, "interior-website");
						
						$query = "select * from mathang";
                        $result = mysqli_query($link, $query);
                        
                        // Pagination
                        // How many records per page
                        $rpp = 7;

                        // Check for set pgae
                        isset($_GET['page']) ? $page = $_GET['page'] : $page = 0;

                        // Check for page 1
                        if($page > 1)
                        {
                            $start = ($page * $rpp) - $rpp;
                        }
                        else
                        {
                            $start = 0;
                        }

                        // Query db for TOTAL records
                        $resultSet = mysqli_query($link, "SELECT MSMatHang FROM mathang");

                        // Get total records
                        $numRows = $resultSet->num_rows;

                        //Get total number of pages
                        $totalPages = $numRows / $rpp;
                        
                        // Query results
                        $resultSet = mysqli_query($link, "SELECT * FROM mathang LIMIT $start, $rpp");

                        // echo "<table>";
                        // while($r = mysqli_fetch_assoc($resultSet))
						// 	{
                
						// 		//$MSMatHang = $r["MSMatHang"];
						// 		$TenMatHang = $r["TenMatHang"];
						// 		//$DVT = $r["DVT"];
						// 		//$MSLoai = $r["MSLoai"];
						// 		$DonGia = $r["DonGia"];
                        //         $MoTa = $r["MoTa"];

                        //         echo "<tr><td>$TenMatHang</td><td>$DonGia</td><td>$MoTa</td></tr>";
                        //     }
                        //     echo "";
                        // echo "</table>";
                        //           for($x = 1; $x <= $totalPages; $x++)
                        //           {
                        //               echo "<a href='?page=$x'>$x</a>";
                        //           }
                    

						if(mysqli_num_rows($result) > 0)
						{
                            $column = 0;
							while($r = mysqli_fetch_assoc($resultSet))
							{
                                $column++;
								//$MSMatHang = $r["MSMatHang"];
								$TenMatHang = $r["TenMatHang"];
								//$DVT = $r["DVT"];
								//$MSLoai = $r["MSLoai"];
								$DonGia = $r["DonGia"];
								$MoTa = $r["MoTa"];
								$HinhAnh = $r["HinhAnh"];
                                
                                echo "<div class='special_products_row1'>";
									echo "<div><a href=''><img src='upload/$HinhAnh' width='178' height='131' /></a></div>";
                                    echo "<div class='text_brown'>";
                                    echo GioiHanKiTu($TenMatHang, 27);
                                    echo "</div> <div class='text_red'>$DonGia VND</div>";
                                    echo "<div class='text_special_products'>";
                                    echo GioiHanKiTu($MoTa, 47);
                                    echo "</div>";
									echo "<div>";
										echo "<a href=='' class='detail_special_products'>Chi tiết</a>";
										echo "<input type='submit' class='cart_special_products' value='+ Giỏ hàng' width='93'>";
                                    echo "</div>";
                                echo "</div>";
                                
                                if($column % 4 == 0)
                                {
                                    echo "<div class='clear'></div>";
                                }
                            }  
                        }
                            echo "<div>";
                            echo "<img src='images/arrow_gray.png' width='742' height='1' /> ";
                            echo "</div>";
                        echo"</div>";
                    
                        echo "<div>";
                            for($x = 1; $x <= $totalPages + 1; $x++)
                            {
                                echo "<div class='paging'><a href='?page=$x'> $x</a></div>";
                            }
                        echo "</div>";
                    ?>
            </div>
             
                
            </article>
                
        </div>
        <div class="clear18"></div>
 
        <footer>
            <div class="footer-menu">
               	<a href="#">Trang chủ</a><a href="#">Sản phẩm mới</a> <a href="#">Sản phẩm đặc biệt</a> <a href="#">Tất cả sản phẩm</a><a href="#"> Câu hỏi thường gặp</a> <a href="#">Liên hệ</a>
            </div>
        </footer>
    </body>
</html>
