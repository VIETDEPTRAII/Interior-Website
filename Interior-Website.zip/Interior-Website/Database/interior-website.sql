-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 12, 2019 at 04:51 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `interior-website`
--

-- --------------------------------------------------------

--
-- Table structure for table `capquyen`
--

CREATE TABLE `capquyen` (
  `TuCach` int(1) NOT NULL,
  `MSMau` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `Quyen` varchar(4) COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `capquyen`
--

INSERT INTO `capquyen` (`TuCach`, `MSMau`, `Quyen`) VALUES
(1, 'HDC', '0001'),
(1, 'HDCT', '0001'),
(1, 'KH', '0001'),
(1, 'MH', '0001'),
(1, 'QL', '0000'),
(2, 'HDC', '1111'),
(2, 'HDCT', '1111'),
(2, 'KH', '1111'),
(2, 'MH', '1111'),
(2, 'QL', '1111');

-- --------------------------------------------------------

--
-- Table structure for table `dangnhap`
--

CREATE TABLE `dangnhap` (
  `TenDangNhap` varchar(50) COLLATE utf8_vietnamese_ci NOT NULL,
  `MatKhau` varchar(50) COLLATE utf8_vietnamese_ci NOT NULL,
  `TuCach` int(1) NOT NULL,
  `MSThamChieu` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `dangnhap`
--

INSERT INTO `dangnhap` (`TenDangNhap`, `MatKhau`, `TuCach`, `MSThamChieu`) VALUES
('hnk', '123', 2, 'QL001'),
('ntv', '333', 1, 'KH001');

-- --------------------------------------------------------

--
-- Table structure for table `hoadonchitiet`
--

CREATE TABLE `hoadonchitiet` (
  `MSHoaDon` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `MSMatHang` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `DonGia` int(11) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `TriGia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hoadonchung`
--

CREATE TABLE `hoadonchung` (
  `MSHoaDon` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `NgayBan` date NOT NULL,
  `MSKhachHang` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `MSKhachHang` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `HoKhachHang` text COLLATE utf8_vietnamese_ci NOT NULL,
  `TenKhachHang` text COLLATE utf8_vietnamese_ci NOT NULL,
  `DiaChi` text COLLATE utf8_vietnamese_ci NOT NULL,
  `SDT` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`MSKhachHang`, `HoKhachHang`, `TenKhachHang`, `DiaChi`, `SDT`) VALUES
('KH001', 'Nguyễn', 'Thanh Việt', '491 Hậu Giang P.11 Q.6 TP.HCM', 904716299);

-- --------------------------------------------------------

--
-- Table structure for table `mathang`
--

CREATE TABLE `mathang` (
  `MSMatHang` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `TenMatHang` text COLLATE utf8_vietnamese_ci NOT NULL,
  `DVT` text COLLATE utf8_vietnamese_ci NOT NULL,
  `MSLoai` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `DonGia` int(11) NOT NULL,
  `HinhAnh` binary(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `mathang`
--

INSERT INTO `mathang` (`MSMatHang`, `TenMatHang`, `DVT`, `MSLoai`, `DonGia`, `HinhAnh`) VALUES
('MH001', 'Giường (có nệm)', 'Cái', 'PN', 2350000, 0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);

-- --------------------------------------------------------

--
-- Table structure for table `mauform`
--

CREATE TABLE `mauform` (
  `MSMau` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `TenMau` text COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `mauform`
--

INSERT INTO `mauform` (`MSMau`, `TenMau`) VALUES
('HDC', 'Hóa đơn chung'),
('HDCT', 'Hóa đơn chi tiết'),
('KH', 'Khách hàng'),
('MH', 'Mặt hàng'),
('QL', 'Quản lí');

-- --------------------------------------------------------

--
-- Table structure for table `phanloai`
--

CREATE TABLE `phanloai` (
  `MSLoai` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `TenLoai` text COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `phanloai`
--

INSERT INTO `phanloai` (`MSLoai`, `TenLoai`) VALUES
('PN', 'Phòng ngủ'),
('PT', 'Phòng tắm');

-- --------------------------------------------------------

--
-- Table structure for table `quanli`
--

CREATE TABLE `quanli` (
  `MSQuanLi` varchar(10) COLLATE utf8_vietnamese_ci NOT NULL,
  `HoQuanLi` text COLLATE utf8_vietnamese_ci NOT NULL,
  `TenQuanLi` text COLLATE utf8_vietnamese_ci NOT NULL,
  `DiaChi` text COLLATE utf8_vietnamese_ci NOT NULL,
  `SDT` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `quanli`
--

INSERT INTO `quanli` (`MSQuanLi`, `HoQuanLi`, `TenQuanLi`, `DiaChi`, `SDT`) VALUES
('QL001', 'Huỳnh', 'Ngọc Khánh', 'B28/6 Tân Thới Hiệp Q.12', 778074976);

-- --------------------------------------------------------

--
-- Table structure for table `tucachtacnhan`
--

CREATE TABLE `tucachtacnhan` (
  `TuCach` int(1) NOT NULL,
  `TacNhan` text COLLATE utf8_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_vietnamese_ci;

--
-- Dumping data for table `tucachtacnhan`
--

INSERT INTO `tucachtacnhan` (`TuCach`, `TacNhan`) VALUES
(1, 'Khách hàng'),
(2, 'Quản lí');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `capquyen`
--
ALTER TABLE `capquyen`
  ADD PRIMARY KEY (`TuCach`,`MSMau`),
  ADD KEY `FK_CAPQUYEN_MAUFORM_MSMAU` (`MSMau`);

--
-- Indexes for table `dangnhap`
--
ALTER TABLE `dangnhap`
  ADD PRIMARY KEY (`TenDangNhap`),
  ADD KEY `FK_DANGNHAP_TUCACHTACNHAN_TUCACH` (`TuCach`);

--
-- Indexes for table `hoadonchitiet`
--
ALTER TABLE `hoadonchitiet`
  ADD PRIMARY KEY (`MSHoaDon`,`MSMatHang`),
  ADD KEY `FK_HOADONCHITIET_MATHANG_MSMATHANG` (`MSMatHang`);

--
-- Indexes for table `hoadonchung`
--
ALTER TABLE `hoadonchung`
  ADD PRIMARY KEY (`MSHoaDon`),
  ADD KEY `FK_HOADONCHUNG_KHACHHANG_MSMATHANG` (`MSKhachHang`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`MSKhachHang`);

--
-- Indexes for table `mathang`
--
ALTER TABLE `mathang`
  ADD PRIMARY KEY (`MSMatHang`),
  ADD KEY `FK_MATHANG_PHANLOAI_MSLOAI` (`MSLoai`);

--
-- Indexes for table `mauform`
--
ALTER TABLE `mauform`
  ADD PRIMARY KEY (`MSMau`);

--
-- Indexes for table `phanloai`
--
ALTER TABLE `phanloai`
  ADD PRIMARY KEY (`MSLoai`);

--
-- Indexes for table `quanli`
--
ALTER TABLE `quanli`
  ADD PRIMARY KEY (`MSQuanLi`);

--
-- Indexes for table `tucachtacnhan`
--
ALTER TABLE `tucachtacnhan`
  ADD PRIMARY KEY (`TuCach`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `capquyen`
--
ALTER TABLE `capquyen`
  ADD CONSTRAINT `FK_CAPQUYEN_MAUFORM_MSMAU` FOREIGN KEY (`MSMau`) REFERENCES `mauform` (`MSMau`),
  ADD CONSTRAINT `FK_CAPQUYEN_TUCACHTACNHAN_TUCACH` FOREIGN KEY (`TuCach`) REFERENCES `tucachtacnhan` (`TuCach`);

--
-- Constraints for table `dangnhap`
--
ALTER TABLE `dangnhap`
  ADD CONSTRAINT `FK_DANGNHAP_TUCACHTACNHAN_TUCACH` FOREIGN KEY (`TuCach`) REFERENCES `tucachtacnhan` (`TuCach`);

--
-- Constraints for table `hoadonchitiet`
--
ALTER TABLE `hoadonchitiet`
  ADD CONSTRAINT `FK_HOADONCHITIET_HOADONCHUNG_MSHOADON` FOREIGN KEY (`MSHoaDon`) REFERENCES `hoadonchung` (`MSHoaDon`),
  ADD CONSTRAINT `FK_HOADONCHITIET_MATHANG_MSMATHANG` FOREIGN KEY (`MSMatHang`) REFERENCES `mathang` (`MSMatHang`);

--
-- Constraints for table `hoadonchung`
--
ALTER TABLE `hoadonchung`
  ADD CONSTRAINT `FK_HOADONCHUNG_KHACHHANG_MSMATHANG` FOREIGN KEY (`MSKhachHang`) REFERENCES `khachhang` (`MSKhachHang`);

--
-- Constraints for table `mathang`
--
ALTER TABLE `mathang`
  ADD CONSTRAINT `FK_MATHANG_PHANLOAI_MSLOAI` FOREIGN KEY (`MSLoai`) REFERENCES `phanloai` (`MSLoai`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
