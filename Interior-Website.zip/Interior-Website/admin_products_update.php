<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="admin-page.css" rel="stylesheet" type="text/css" />
        <title>Cập nhật sản phẩm</title>
	</head>

	<body>
		<div class="wrapper">
        	<div class="aside">
            	<div class="admin_title">
                	Trang quản lý
                </div>
                
                <nav>
                	<ul>
                    	<li><a href="admin_products.php">Sản phẩm</a></li>
                        <li><a href="#">Khách hàng</a></li>
                        <li><a href="#">Nhân viên</a></li>
                        <li><a href="#">Thư</a></li>
                        <li><a href="#">Tài khoản</a></li>
                    </ul>
                </nav>
            </div>
            
			
            <div class="content">
            	<header>
                	<div class="header-right">
                    
                    	<div class="admin_search">
                        <input type="search" class="admin_text_search" id="admin_text_search" placeholder="Tìm kiếm"/>
                        <input type="button" class="andmin_btn_search"/>
                        </div>
                    	
                        <div class="message_and_notification">
                    		<a href="#" class="i_message"><img src="images/i_message.png" width="29" height="21" /> 
                            	<span class="message_badge">3</span>
                            </a>
                            	
                          <a href="#" class="i_notification"><img src="images/i_notification.png" width="26" height="21" />
                            	<span class="notification_badge">2</span>
                            </a>
                   	  	</div>
                        <div class="admin_info">
                            <div class="avatar_admin">
                            	<img src="images/avatar_admin.png" width="38" height="38" />
                            </div>
                            <div class="admin_name_dropdown">
                                <div class="admin_name">
                                    <a href="">Chào, Laura</a>
                                </div>
                                <div class="dropdown_arrow">    
                                    <a href=""><img src="images/dropdown_arrow.png" width="18" height="16"/></a>
                                </div>
                            </div>
                        </div>
                    </div>         
                </header>
                
                <article>
                	<form method="post">
                	<div class="article_top">
						<?php
                            $link = mysqli_connect("localhost", "root", "");
							mysqli_set_charset($link, 'UTF8');
                            mysqli_select_db($link, "interior-website");
                            
                            if (isset($_GET["id_update"]))
                            {
                                $query = "select * from mathang where MSMatHang = '".$_GET["id_update"]."'";
                                $result = mysqli_query($link, $query);
                                
                                if(mysqli_num_rows($result) > 0)
                                {
                                    while($r = mysqli_fetch_assoc($result))
                                    {
                                        $MSMatHang = $r["MSMatHang"];
                                        $TenMatHang = $r["TenMatHang"];
                                        $DVT = $r["DVT"];
                                        $MSLoai = $r["MSLoai"];
										$DonGia = $r["DonGia"];
										$MoTa = $r["MoTa"];
	                                    $HinhAnh = $r["HinhAnh"];
                                        
										echo "<table class='admin_products_table'>";
										echo "<tr>";
										echo "<td align='center' colspan='7' class='first_row'>CẬP NHẬT SẢN PHẨM</td>";
										echo "</tr>";
										echo "<tr>";
										echo "<td align='center' class='cell'>MS SẢN PHẨM</td>";
										echo "<td align='center' class='cell cell_width'>TÊN SẢN PHẨM</td>";
										echo "<td align='center' width='50px' class='cell'>ĐƠN VỊ TÍNH</td>";
										echo "<td align='center' width='50px' class='cell'>MÃ SỐ LOẠI</td>";
										echo "<td align='center' width='100' class='cell'>ĐƠN GIÁ</td>";
										echo "<td align='center' width='150' class='cell'>MÔ TẢ</td>";
										echo "<td align='center' width='100' class='cell' >HÌNH ẢNH</td>";
										echo "</tr>";
                                        
                                        echo "<tr>";
                                        echo "<td align='center' class='cell'>$MSMatHang</td>";
                                        echo "<td align='center'><input type='text' id='TenMatHang' name='TenMatHang' value='$TenMatHang' size='30'</td>";
                                        echo "<td><input type='DVT' id='DVT' name='DVT' value='$DVT' size='20'></td>";
										$query = "select * from phanloai group by TenLoai";//Câu lệnh truy vấn
										$result = mysqli_query($link, $query);//Kết quả thực thi truy vấn
										$num = mysqli_num_rows($result);//Số dòng của kết quả thực thi
										echo "<td align='center'>";
										echo "<select id='MSLoai' name='MSLoai' class='dropbox'>";
										if($num > 0)
										{
											while($r = mysqli_fetch_assoc($result))//Lấy MSLoai
											{
												echo "<option>";
												echo $r['MSLoai'];
												echo "</option>";
											}
										}
										echo "</select>";
										echo "</td>";
										echo "<td><input type='text' id='DonGia' name='DonGia' value='$DonGia' size='30'></td>";
										echo "<td><input type='text' id='DonGia' name='MoTa' value='$MoTa' size='30'></td>";
										echo "<td><input type='text' id='HinhAnh' name='HinhAnh' value='$HinhAnh' size='30'></td>";
                                        echo "<tr>";
                                        echo "<td colspan='6' align='center' class='btnSua'><input type='submit' name='btnSua' id='btnSua' value='LƯU' class='button'></td>";
                                        echo "</tr>";
                                    }
                                    
                                    echo "</table>";
                                }
                            }
                            
                            if(isset($_POST["btnSua"]))
                            {
                                $MSMatHang = $_GET["id_update"];
                                $TenMatHang = $_POST["TenMatHang" ];
                                $DVT = $_POST["DVT"];
                                $MSLoai = $_POST["MSLoai"];
								$DonGia = $_POST["DonGia"];
								$MoTa = $_POST["MoTa"];
	                            $HinhAnh = $_POST["HinhAnh"];
                                
                                if(empty($TenMatHang) || empty($DVT) || empty($MSLoai) || empty($DonGia))
                                {
                                    echo "<script>alert('Thông tin chưa đầy đủ !')</script>";
                                }
                                
                                else 
                                {
                                    $query = "update mathang set TenMatHang='$TenMatHang', DVT='$DVT', MSLoai='$MSLoai', DonGia='$DonGia',
									 MoTa='$MoTa' where MSMatHang='$MSMatHang'";
									
                                    mysqli_query($link, $query);
                                    
                                    // Chuyển về trang trước bằng Javascript ^_^
                                    echo "<script>";
                                    echo "location.replace('admin_products.php')";
                                    echo "</script>";
                                }
                            }
                        ?>
                    </form>    
                    <div class="article_bottom">
                           
                    </div>
                </article>
            </div>
        </div>
    </body>
</html>
