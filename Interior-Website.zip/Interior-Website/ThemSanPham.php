<?php
if(isset($_POST["MSMatHang"]) && isset($_POST["TenMatHang"]) && isset($_POST["DVT"]) && isset($_POST["MSLoai"]) && isset($_POST["DonGia"]))
{
	$MSMatHang = $_POST["MSMatHang"];
	$TenMatHang = $_POST["TenMatHang"];
	$DVT = $_POST["DVT"];
	$MSLoai = $_POST["MSLoai"];
	$DonGia = $_POST["DonGia"];
	/*$HinhAnh = $r["HinhAnh"];*/
	
	if(empty($MSMatHang) || empty($TenMatHang) || empty($DVT) || empty($MSLoai) || empty($DonGia))
	{
		echo "<script>alert('Thông tin chưa đầy đủ !')</script>";	
	}
	else
	{
		$query = "insert into mathang(MSMatHang, TenMatHang, DVT, 
		MSLoai, DonGia) values('$MSMatHang', '$TenMatHang', '$DVT', '$MSLoai', '$DonGia')";
		
		$result = mysqli_query($link, $query);

		if(!$result)
		{
			echo "<script>alert('Thêm sản phẩm thất bại !')</script>";
		}	
	}
}
?>