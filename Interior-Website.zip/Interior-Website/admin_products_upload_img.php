<form method="post" enctype="multipart/form-data">
<?php
//Nếu có chọn hình
	if(isset($_GET["image_name"]))
	{
		//Gán biến $image_name lấy được từ url của trang web (tên hình đang được chọn) vào $img_name
		$img_name = $_GET["image_name"];
		
		//Show hình đang được chọn ra
		echo "<span class='upload_left'><img src='"."upload/".$img_name."' width='100px' height='100px'></span>";
		
		//Nếu vấm vào nút Thêm
		if(isset($_POST["btnThem"]))
		{
			//Gán các thông tin dã nhập vào các biến tương ứng
			if(isset($_POST["MSMatHang"]) && isset($_POST["TenMatHang"]) && isset($_POST["DVT"]) && 
			isset($_POST["MSLoai"]) && isset($_POST["DonGia"]))
			{
				$MSMatHang = $_POST["MSMatHang"];
				$TenMatHang = $_POST["TenMatHang"];
				$DVT = $_POST["DVT"];
				$MSLoai = $_POST["MSLoai"];
				$DonGia = $_POST["DonGia"];
				$MoTa = $_POST["MoTa"];
				$HinhAnh = $img_name;
				
				//Kiểm tra thông tin nhập vào có đủ không
				//Nếu không đủ thì thông báo
				if(empty($MSMatHang) || empty($TenMatHang) || empty($DVT) || empty($MSLoai) || empty($DonGia))
				{
					echo "<script>alert('Thông tin chưa đầy đủ !')</script>";	
				}
				else//Ngược lại thì thêm vào bảng mathang
				{
					$query = "insert into mathang(MSMatHang, TenMatHang, DVT,
					MSLoai, DonGia, MoTa, HinhAnh) values('$MSMatHang', '$TenMatHang', '$DVT', '$MSLoai', '$DonGia', '$MoTa', '$HinhAnh')";
					
					$result = mysqli_query($link, $query);
			
					if($result)
					{
						echo "<script>alert('Đã thêm sản phẩm thành công')</script>";
						echo "<script>window.open(location.reload(true))</script>";
					}									
				}
			}
		}
	}
	else//Nếu chưa chọn hình
	{
		//Nếu vấm vào nút Thêm
		if(isset($_POST["btnThem"]))
		{
			//Gán các thông tin dã nhập vào các biến tương ứng
			if(isset($_POST["MSMatHang"]) && isset($_POST["TenMatHang"]) && isset($_POST["DVT"]) && 
			isset($_POST["MSLoai"]) && isset($_POST["DonGia"]))
			{
				$MSMatHang = $_POST["MSMatHang"];
				$TenMatHang = $_POST["TenMatHang"];
				$DVT = $_POST["DVT"];
				$MSLoai = $_POST["MSLoai"];
				$DonGia = $_POST["DonGia"];
				$MoTa = $_POST["MoTa"];
				
				//Kiểm tra thông tin nhập vào có đủ không
				//Nếu không đủ thì thông báo
				if(empty($MSMatHang) || empty($TenMatHang) || empty($DVT) || empty($MSLoai) || empty($DonGia))
				{
					echo "<script>alert('Thông tin chưa đầy đủ !')</script>";
				}
				else//Ngược lại thì thêm vào bảng mathang
				{
					$query = "insert into mathang(MSMatHang, TenMatHang, DVT,
					MSLoai, DonGia) values('$MSMatHang', '$TenMatHang', '$DVT', '$MSLoai', '$DonGia')";
					
					$result = mysqli_query($link, $query);
			
					if($result)
					{
						echo "<script>alert('Đã thêm sản phẩm thành công')</script>";
						echo "<script>window.open(location.reload(true))</script>";
					}									
				}
			}
		}	
	}    
?>
  <div class="upload_right">
      <div class="btn_upload"><input type="file" name="image" id="image" value="Chọn"/></div>
      <div class="btn_upload"><input type="submit" name="upload" id="upload" value="Tải hình lên"/></div>
  </div>
</form>
<tr>
    <td colspan='2' align="center" class="btnThem"><input type="submit" name="btnThem" id="btnThem" value="Thêm"/></td>
</tr>
<?php
    if(isset($_POST["upload"]))
    {
		if(isset($_FILES['image']['name']))
		{
        $target = "upload/".basename($_FILES['image']['name']);
        $link = mysqli_connect("localhost", "root", "", "interior-website");
		mysqli_set_charset($link, 'UTF8');
        $image_name = $_FILES['image']['name'];
		
		//Nếu có chọn hình thì thay đổi đường dẫn của trang (để lấy biến $image_name)
		echo "<script>window.location.href = 'admin_products.php?image_name=$image_name'</script>";
		
		//Mảng các định dạng cho phép (trong project này là hình)
		$allowed = array("jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png");

		//Kiểm tra định dạng file hình
        $ext = pathinfo($image_name, PATHINFO_EXTENSION);
		if(!array_key_exists($ext, $allowed)) echo ("Không đúng định dạng ! ");
		
		//Kiểm tra số dòng của bảng uploadhinh
        $query_row_count = "select * from uploadhinh";
        $result_row_count =  mysqli_query($link, $query_row_count);

		//Nếu số dòng trả về là 0 (tức là hình được chọn chưa từng được upload) thì thêm hình đó vào bảng uploadhinh
        if(mysqli_num_rows($result_row_count) == 0)
        {
            $query_insert_upload = "insert into uploadhinh(url) values('$image_name')";
            mysqli_query($link, $query_insert_upload);

            $msg = "";
            if(move_uploaded_file($_FILES['image']['tmp_name'], $target))
            {
                $msg = "Đã tải hình lên !";
            }
            else
            {
                $msg = "Xảy ra lỗi !";
            }

            echo $msg;
        }
        else//Ngược lại nếu số dòng trả về lớn hơn 0 (tức là hình đã được upload rồi) thì không thêm vào bảng uploadhinh nữa (chiếm chỗ csdl)
        {
            $query_exist = "select * from uploadhinh where url = '$image_name'";
            $result_exist = mysqli_query($link, $query_exist);
            
            if(mysqli_num_rows($result_exist) == 0)
            {
                $query_insert = "insert into uploadhinh(url) values('$image_name')";
                mysqli_query($link, $query_insert);

                $msg = "";
                if(move_uploaded_file($_FILES['image']['tmp_name'], $target))
                {
                    $msg = "Đã tải hình lên !";
                }
                else
                {
                    $msg = "Xảy ra lỗi !";
                }

                echo $msg;
            }
        }
		}
		else
		{
			echo "<br>Vui lòng chọn hình !";	
		}
 	}  	

	
	//Show thông tin sản phẩm
	$link = mysqli_connect("localhost", "root", "");
	mysqli_set_charset($link, 'UTF8');
	mysqli_select_db($link, "interior-website");
	
	$query = "select * from mathang";
	$result = mysqli_query($link, $query);
	$i = 0;
	
	if(mysqli_num_rows($result) > 0)
	{
		while($r = mysqli_fetch_assoc($result))
		{
			
			$i++;
			$MSMatHang = $r["MSMatHang"];
			$TenMatHang = $r["TenMatHang"];
			$DVT = $r["DVT"];
			$MSLoai = $r["MSLoai"];
			$DonGia = $r["DonGia"];
			$MoTa = $r["MoTa"];
			$HinhAnh = $r["HinhAnh"];
			
			if($i == 1)
			{
				echo "<table class='admin_products_table'>";
				echo "<tr>";
				echo "<td align='center' colspan='11' class='first_row'>THÔNG TIN SẢN PHẨM</td>";
				echo "</tr>";
				echo "<tr>";
				echo "<td align='center' width='100' class='cell'>MÃ SẢN PHẨM</td>";
				echo "<td align='center' width='200' class='cell'>TÊN SẢN PHẨM</td>";
				echo "<td align='center' width='100' class='cell'>ĐƠN VỊ TÍNH</td>";
				echo "<td align='center' width='100' class='cell'>MÃ LOẠI</td>";
				echo "<td align='center' width='100' class='cell'>ĐƠN GIÁ</td>";
				echo "<td align='center' width='80' class='cell'>MÔ TẢ</td>";
				echo "<td align='center' width='80' class='cell'>HÌNH ẢNH</td>";
				echo "<td colspan='2' align='center' width='150' class='cell'></td>";
				echo "</tr>";          
			}
			
											 
			echo "<tr>";
			echo "<td align='center' width='100' class='nextrow'>$MSMatHang</td>";
			echo "<td align='center' class='nextrow'>$TenMatHang</td>";
			echo "<td align='center' class='nextrow'>$DVT</td>";
			echo "<td align='center' class='nextrow'>$MSLoai</td>";
			echo "<td align='center' class='nextrow'>$DonGia</td>";
			echo "<td align='center' class='nextrow'>$MoTa</td>";
			echo "<td align='center' class='nextrow'><img src='upload/$HinhAnh' width='80' height='80'></td>";
			echo "<td class='cell' width='140'>";
			echo "<div align='center' class='delete'><a href='admin_products_delete.php?id_delete=$MSMatHang' onClick='deleteConfirm()'>Xóa</a></div>";
			echo "<div align='center' class='update'><a href='admin_products_update.php?id_update=$MSMatHang'>Sửa</a></div>";
			echo "</td>";
			echo "</tr>";
		}
		
		echo "</table>";
	}
?>