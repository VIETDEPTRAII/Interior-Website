<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="admin-page.css" rel="stylesheet" type="text/css" />
        <title>Admin</title>
	</head>

	<body>
		<div class="wrapper">
        	<div class="aside">
            	<div class="admin_title">
                	Trang quản lý
                </div>
                
                <nav>
                	<ul>
                    	<li><a href="admin_products.php">Sản phẩm</a></li>
                        <li><a href="#">Khách hàng</a></li>
                        <li><a href="#">Nhân viên</a></li>
                        <li><a href="#">Thư</a></li>
                        <li><a href="#">Tài khoản</a></li>
                    </ul>
                </nav>
            </div>
            
			
            <div class="content">
            	<header>
                	<div class="header-right">
                    
                    	<div class="admin_search">
                        <input type="search" class="admin_text_search" id="admin_text_search" placeholder="Tìm kiếm"/>
                        <input type="button" class="andmin_btn_search"/>
                        </div>
                    	
                        <div class="message_and_notification">
                    		<a href="#" class="i_message"><img src="images/i_message.png" width="29" height="21" /> 
                            	<span class="message_badge">3</span>
                            </a>
                            	
                          <a href="#" class="i_notification"><img src="images/i_notification.png" width="26" height="21" />
                            	<span class="notification_badge">2</span>
                            </a>
                   	  	</div>
                        <div class="admin_info">
                            <div class="avatar_admin">
                            	<img src="images/avatar_admin.png" width="38" height="38" />
                            </div>
                            <div class="admin_name_dropdown">
                                <div class="admin_name">
                                    <a href="">Chào, Laura</a>
                                </div>
                                <div class="dropdown_arrow">    
                                    <a href=""><img src="images/dropdown_arrow.png" width="18" height="16"/></a>
                                </div>
                            </div>
                        </div>
                    </div>         
                </header>
                
                <article>
                	<div class="article_top">
                        <div class="TableSanPham_title">QUẢN LÍ SẢN PHẨM</div>
                        <table class="TableSanPham">
                            <tr>
                                <td class="table-row">Mã sản phẩm</td>
                                <td class="table-row"><input type="text" name="MaSP" id="MaSP" placeholder="Nhập sản phẩm" class="textboxSanPham"/></td>
                            </tr>
                            <tr>
                                <td class="table-row">Tên sản phẩm</td>
                                <td class="table-row"><input type="text" name="TenSP" id="TenSP" placeholder="Nhập tên sản phẩm" class="textboxSanPham"/></td>
                            </tr>
                            <tr>
                                <td class="table-row">Đơn vị tính</td>
                                <td class="table-row"><input type="text" name="DVT" id="DVT" placeholder="Nhập đơn vị tính" class="textboxSanPham"/></td>
                            </tr>
                            <tr>
                                <td class="table-row">Mã số loại</td>
                                <td class="table-row"><input type="text" name="MaLoai" id="MaLoai" placeholder="Nhập mã số loại" class="textboxSanPham"/></td>
                            </tr>
                            <tr>
                                <td class="table-row">Đơn giá</td>
                                <td class="table-row"><input type="text" name="DonGia" id="DonGia" placeholder="Nhập đơn giá" class="textboxSanPham"/></td>
                            </tr>
                            <tr>
                                <td class="table-row">Hình ảnh</td>
                                <td class="table-row"></td>
                            </tr>
                        </table>
                        <div class="btnThem">
                        	<input type="submit" name="btnThem" id="btnThem" value="Thêm" />
                        </div>
                     </div>
                     
                     <div class="article_bottom">
                     	<?php													
							$link = mysqli_connect("localhost", "root", "");
							mysqli_set_charset($link, 'UTF8');
							mysqli_select_db($link, "interior-website");
							
							$query = "select * from mathang";
							$result = mysqli_query($link, $query);
							
							if(mysqli_num_rows($result) > 0)
							{
								$i = 0;
								while($r = mysqli_fetch_assoc($result))
								{
									$i++;
									$MaSP = $r["MSMatHang"];
									$TenSP = $r["TenMatHang"];
									$DVT = $r["DVT"];
									$MaLoai = $r["MSLoai"];
									$DonGia = $r["DonGia"];
									$HinhAnh = $r["HinhAnh"];
									
									if($i == 1)
									{
										echo "<table class='admin_products_table'>";
										echo "<tr>";
										echo "<td align='center' colspan='11' class='first_row'>THÔNG TIN SẢN PHẨM</td>";
										echo "</tr>";
										echo "<tr>";
										echo "<td align='center' width='100' class='cell'>MÃ SẢN PHẨM</td>";
										echo "<td align='center' width='200' class='cell'>TÊN SẢN PHẨM</td>";
										echo "<td align='center' width='100' class='cell'>ĐƠN VỊ TÍNH</td>";
										echo "<td align='center' width='100' class='cell'>MÃ LOẠI</td>";
										echo "<td align='center' width='100' class='cell'>ĐƠN GIÁ</td>";
										echo "<td align='center' width='100' class='cell'>HÌNH ẢNH</td>";
										echo "<td colspan='2' align='center' width='100' class='cell'></td>";
										echo "</tr>";
									}
																	 
									echo "<tr>";
									echo "<td align='center' width='100' class='nextrow'>$MaSP</td>";
									echo "<td align='center' class='nextrow'>$TenSP</td>";
									echo "<td align='center' class='nextrow'>$DVT</td>";
									echo "<td align='center' class='nextrow'>$MaLoai</td>";
									echo "<td align='center' class='nextrow'>$DonGia</td>";
									echo "<td align='center' class='nextrow'>$HinhAnh</td>";
									
									echo "<td width='80' align='center' class='delete'><a href='XoaMayBay.php?id_delete=$MaSP'>Xóa</a></td>";
									echo "<td width='80' align='center' class='update'><a href='SuaMayBay.php?id_update=$MaSP'>Sửa</a></td>";
									echo "</tr>";
									
									
								}
								
								echo "</table>";
							}
							else
							{
								echo "<script>alert('Không có dữ liệu trong bảng !')</script>";
								echo "<table class='table'>";
							}
						?>
                     </div>
                </article>
            </div>
        
        </div>
    </body>
</html>
