<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link href="admin-page.css" rel="stylesheet" type="text/css" />
        <script type="text/javascript" src="js/MyScript.js"></script>
        <title>Admin</title>
	</head>
	<body>
		<div class="wrapper">
        	<div class="aside">
            	<div class="admin_title">
                	Trang quản lý
                </div>
                
                <nav>
                	<ul>
                    	<li><a href="admin_products.php">Sản phẩm</a></li>
                        <li><a href="#">Khách hàng</a></li>
                        <li><a href="#">Nhân viên</a></li>
                        <li><a href="#">Thư</a></li>
                        <li><a href="#">Tài khoản</a></li>
                    </ul>
                </nav>
            </div>
            
			
            <div class="content">
            	<header>
                	<div class="header-right">
                    
                    	<div class="admin_search">
                        <input type="search" class="admin_text_search" id="admin_text_search" placeholder="Tìm kiếm"/>
                        <input type="button" class="andmin_btn_search"/>
                        </div>
                    	
                        <div class="message_and_notification">
                    		<a href="#" class="i_message"><img src="images/i_message.png" width="29" height="21" /> 
                            	<span class="message_badge">3</span>
                            </a>
                            	
                          	<a href="#" class="i_notification"><img src="images/i_notification.png" width="26" height="21" />
                            	<span class="notification_badge">2</span>
                            </a>
                   	  	</div>
                        <div class="admin_info">
                            <div class="avatar_admin">
                            	<img src="images/avatar_admin.png" width="38" height="38" />
                            </div>
                            <div class="admin_name_dropdown">
                                <div class="admin_name">
                                    <a href="">Chào, Laura</a>
                                </div>
                                <div class="dropdown_arrow">    
                                    <a href=""><img src="images/dropdown_arrow.png" width="18" height="16"/></a>
                                </div>
                            </div>
                        </div>
                    </div>         
                </header>
                
                <article>
                	<form method="post" enctype="multipart/form-data">
                	<div class="article_top">
                            <table class="TableSanPham">
                            	<tr>
                                	<td align="center" class="TableSanPham_title" colspan="2">QUẢN LÍ SẢN PHẨM</td>
                                </tr>
                                <tr>
                                    <td class="table-row">Mã sản phẩm</td>
                                    <td class="table-row"><input type="text" name="MSMatHang" id="MSMatHang" placeholder="Nhập sản phẩm" class="textboxSanPham"/></td>
                                    <span id="id-prodcuts-result"></span>
                                </tr>
                                <tr>
                                    <td class="table-row">Tên sản phẩm</td>
                                    <td class="table-row"><input type="text" name="TenMatHang" id="TenMatHang" placeholder="Nhập tên sản phẩm" class="textboxSanPham"/></td>
                                </tr>
                                <tr>
                                    <td class="table-row">Đơn vị tính</td>
                                    <td class="table-row"><input type="text" name="DVT" id="DVT" placeholder="Nhập đơn vị tính" class="textboxSanPham"/></td>
                                </tr>
                                <tr>
                                    <td class="table-row">Mã số loại</td>
                                    <td class="table-row"> 
                                        <?php include "admin_products_dropdown.php"; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="table-row">Đơn giá</td>
                                    <td class="table-row"><input type="text" name="DonGia" id="DonGia" placeholder="Nhập đơn giá" class="textboxSanPham"/></td>
                                </tr>
                                <tr>
                                    <td class="table-row">Mô tả</td>
                                    <td class="table-row"><input type="text" name="MoTa" id="MoTa" placeholder="Nhập mô tả" class="textboxSanPham"/></td>
                                </tr>
                                <tr>
                                    <td class="table-row">Hình ảnh</td>
                                    <td class="table-row">
										<?php include "admin_products_upload_img.php"; ?>
                                    </td>
                                </tr>
                            </table>
                    </div>
                    </form>    
                    <div class="article_bottom">
                           
                    </div>
                </article>
            </div>
        </div>
    </body>
</html>
