<?php
	$link = mysqli_connect("localhost", "root", "");
    mysqli_set_charset($link, 'UTF8');
    mysqli_select_db($link, "interior-website");
    
    $query = "select * from phanloai group by TenLoai";//Câu lệnh truy vấn
    $result = mysqli_query($link, $query);//Kết quả thực thi truy vấn
    $num = mysqli_num_rows($result);//Số dòng của kết quả thực thi
    
    echo "<select id='MSLoai' name='MSLoai' class='dropbox'>";
    if($num > 0)
    {
        while($r = mysqli_fetch_assoc($result))
        {
            echo "<option>";
            echo $r['MSLoai'];
            echo "</option>";
        }
    }
    echo "</select>";
?>