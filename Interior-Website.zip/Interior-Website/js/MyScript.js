﻿function deleteConfirm(delid)
{
    var retVal = confirm("Bạn có chắc chắn muốn xóa sản phẩm này ?");
    if(retVal == true)
    {      
        return true;
        window.location.href = 'admin_products_delete.php?id_delete=' + delid +''; 
    }
    else
    {
        return false;
    }
}