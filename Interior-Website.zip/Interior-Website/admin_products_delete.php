<?php
    $link = mysqli_connect("localhost", "root", "");
    mysqli_select_db($link, "interior-website");
    
    //if (isset($_GET["id_delete"]))
    //{
        //$MSMatHang = $_GET["id_delete"];
        $query = "delete from mathang where MSMatHang='".$_GET['id_delete']."'";
        mysqli_query($link, $query) or die("Xóa thất bại !");
        header("location:admin_products.php");//Chuyển về trang thông tin
    //}

?> 